package b4j.example.designerscripts;
import anywheresoftware.b4a.BA;


public class LS_layout1{

public static void LS_general(anywheresoftware.b4j.objects.LayoutBuilder.LayoutData views, int width, int height, float scale) {
;
//BA.debugLineNum = 3;BA.debugLine="Button1.Width = Pane1.Width/2 - 6dip"[Layout1/General script]
views.get("button1").setPrefWidth((int)((views.get("pane1").getPrefWidth())/2d-(6d * scale)));
//BA.debugLineNum = 4;BA.debugLine="Button2.Left = Button1.Left + Button1.Width + 4dip"[Layout1/General script]
views.get("button2").setLeft((int)((views.get("button1").getLeft())+(views.get("button1").getPrefWidth())+(4d * scale)));
//BA.debugLineNum = 5;BA.debugLine="Button2.Width = Pane1.Width - Button2.Left -4dip"[Layout1/General script]
views.get("button2").setPrefWidth((int)((views.get("pane1").getPrefWidth())-(views.get("button2").getLeft())-(4d * scale)));
//BA.debugLineNum = 7;BA.debugLine="TableView1.SetTopAndBottom(Pane1.Bottom+5dip,100%y-10dip)"[Layout1/General script]
views.get("tableview1").setTop((int)((views.get("pane1").getTop() + views.get("pane1").getPrefHeight())+(5d * scale)));
views.get("tableview1").setPrefHeight((int)((100d / 100 * height)-(10d * scale) - ((views.get("pane1").getTop() + views.get("pane1").getPrefHeight())+(5d * scale))));

}
}