package b4j.example;


import anywheresoftware.b4a.BA;

public class jrdc2utils extends Object{
public static jrdc2utils mostCurrent = new jrdc2utils();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.jrdc2utils", null);
		ba.loadHtSubs(jrdc2utils.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.jrdc2utils", ba);
		}
	}
    public static Class<?> getObject() {
		return jrdc2utils.class;
	}

 public static anywheresoftware.b4a.keywords.Common __c = null;
public static String _rdclink = "";
public static b4j.example.main _main = null;
public static b4j.example.httputils2service _httputils2service = null;
public static String  _addcommand(anywheresoftware.b4a.objects.collections.List _cmdlst,String _cmd,Object[] _params) throws Exception{
 //BA.debugLineNum = 27;BA.debugLine="Public Sub AddCommand(cmdLst As List, cmd As Strin";
 //BA.debugLineNum = 28;BA.debugLine="cmdLst.Add(CreateCommand(cmd, params))";
_cmdlst.Add((Object)(_createcommand(_cmd,_params)));
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
return "";
}
public static b4j.example.main._dbcommand  _createcommand(String _name,Object[] _parameters) throws Exception{
b4j.example.main._dbcommand _cmd = null;
 //BA.debugLineNum = 19;BA.debugLine="Public Sub CreateCommand(Name As String, Parameter";
 //BA.debugLineNum = 20;BA.debugLine="Dim cmd As DBCommand";
_cmd = new b4j.example.main._dbcommand();
 //BA.debugLineNum = 21;BA.debugLine="cmd.Initialize";
_cmd.Initialize();
 //BA.debugLineNum = 22;BA.debugLine="cmd.Name = Name";
_cmd.Name /*String*/  = _name;
 //BA.debugLineNum = 23;BA.debugLine="cmd.Parameters = Parameters";
_cmd.Parameters /*Object[]*/  = _parameters;
 //BA.debugLineNum = 24;BA.debugLine="Return cmd";
if (true) return _cmd;
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return null;
}
public static b4j.example.dbrequestmanager  _createrequest() throws Exception{
b4j.example.dbrequestmanager _req = null;
 //BA.debugLineNum = 13;BA.debugLine="Sub CreateRequest As DBRequestManager";
 //BA.debugLineNum = 14;BA.debugLine="Dim req As DBRequestManager";
_req = new b4j.example.dbrequestmanager();
 //BA.debugLineNum = 15;BA.debugLine="req.Initialize(Me, rdcLink)";
_req._initialize /*String*/ (ba,jrdc2utils.getObject(),_rdclink);
 //BA.debugLineNum = 16;BA.debugLine="Return req";
if (true) return _req;
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return null;
}
public static anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _executecommands(anywheresoftware.b4a.objects.collections.List _cmdlst) throws Exception{
ResumableSub_ExecuteCommands rsub = new ResumableSub_ExecuteCommands(null,_cmdlst);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_ExecuteCommands extends BA.ResumableSub {
public ResumableSub_ExecuteCommands(b4j.example.jrdc2utils parent,anywheresoftware.b4a.objects.collections.List _cmdlst) {
this.parent = parent;
this._cmdlst = _cmdlst;
}
b4j.example.jrdc2utils parent;
anywheresoftware.b4a.objects.collections.List _cmdlst;
int _cmdcount = 0;
b4j.example.httpjob _j = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 32;BA.debugLine="Dim cmdCount As Int = -1";
_cmdcount = (int) (-1);
 //BA.debugLineNum = 34;BA.debugLine="If cmdLst.Size > 0 Then";
if (true) break;

case 1:
//if
this.state = 10;
if (_cmdlst.getSize()>0) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 35;BA.debugLine="Dim j As HttpJob = CreateRequest.ExecuteBatch(cm";
_j = _createrequest()._executebatch /*b4j.example.httpjob*/ (_cmdlst,anywheresoftware.b4a.keywords.Common.Null);
 //BA.debugLineNum = 36;BA.debugLine="Wait For(j) JobDone(j As HttpJob)";
anywheresoftware.b4a.keywords.Common.WaitFor("jobdone", ba, this, (Object)(_j));
this.state = 11;
return;
case 11:
//C
this.state = 4;
_j = (b4j.example.httpjob) result[0];
;
 //BA.debugLineNum = 37;BA.debugLine="If j.Success Then";
if (true) break;

case 4:
//if
this.state = 9;
if (_j._success /*boolean*/ ) { 
this.state = 6;
}else {
this.state = 8;
}if (true) break;

case 6:
//C
this.state = 9;
 //BA.debugLineNum = 38;BA.debugLine="cmdCount = cmdLst.Size";
_cmdcount = _cmdlst.getSize();
 if (true) break;

case 8:
//C
this.state = 9;
 //BA.debugLineNum = 40;BA.debugLine="Log($\"Error executing command: ${j.ErrorMessage";
anywheresoftware.b4a.keywords.Common.LogImpl("61638409",("Error executing command: "+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_j._errormessage /*String*/ ))+""),0);
 if (true) break;

case 9:
//C
this.state = 10;
;
 //BA.debugLineNum = 42;BA.debugLine="j.Release";
_j._release /*String*/ ();
 if (true) break;

case 10:
//C
this.state = -1;
;
 //BA.debugLineNum = 44;BA.debugLine="Return cmdCount";
if (true) {
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,(Object)(_cmdcount));return;};
 //BA.debugLineNum = 45;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _jobdone(b4j.example.httpjob _j) throws Exception{
}
public static void  _executecommands2(Object _mcaller,String _mmethod,anywheresoftware.b4a.objects.collections.List _cmdlst) throws Exception{
ResumableSub_ExecuteCommands2 rsub = new ResumableSub_ExecuteCommands2(null,_mcaller,_mmethod,_cmdlst);
rsub.resume(ba, null);
}
public static class ResumableSub_ExecuteCommands2 extends BA.ResumableSub {
public ResumableSub_ExecuteCommands2(b4j.example.jrdc2utils parent,Object _mcaller,String _mmethod,anywheresoftware.b4a.objects.collections.List _cmdlst) {
this.parent = parent;
this._mcaller = _mcaller;
this._mmethod = _mmethod;
this._cmdlst = _cmdlst;
}
b4j.example.jrdc2utils parent;
Object _mcaller;
String _mmethod;
anywheresoftware.b4a.objects.collections.List _cmdlst;
int _result = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = -1;
 //BA.debugLineNum = 48;BA.debugLine="Wait For (ExecuteCommands(cmdLst)) complete (Resu";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", ba, this, _executecommands(_cmdlst));
this.state = 1;
return;
case 1:
//C
this.state = -1;
_result = (int) result[0];
;
 //BA.debugLineNum = 49;BA.debugLine="CallSubDelayed2(mCaller, mMethod, Result)";
anywheresoftware.b4a.keywords.Common.CallSubDelayed2(ba,_mcaller,_mmethod,(Object)(_result));
 //BA.debugLineNum = 50;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _complete(int _result) throws Exception{
}
public static anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _executelist(b4j.example.main._dbcommand _cmd,anywheresoftware.b4a.objects.collections.List _list1) throws Exception{
ResumableSub_ExecuteList rsub = new ResumableSub_ExecuteList(null,_cmd,_list1);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_ExecuteList extends BA.ResumableSub {
public ResumableSub_ExecuteList(b4j.example.jrdc2utils parent,b4j.example.main._dbcommand _cmd,anywheresoftware.b4a.objects.collections.List _list1) {
this.parent = parent;
this._cmd = _cmd;
this._list1 = _list1;
}
b4j.example.jrdc2utils parent;
b4j.example.main._dbcommand _cmd;
anywheresoftware.b4a.objects.collections.List _list1;
int _result = 0;
b4j.example.main._dbresult _res = null;
Object[] _row = null;
anywheresoftware.b4a.BA.IterableList group5;
int index5;
int groupLen5;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 111;BA.debugLine="Dim Result As Int = -1";
_result = (int) (-1);
 //BA.debugLineNum = 112;BA.debugLine="List1.Clear";
_list1.Clear();
 //BA.debugLineNum = 113;BA.debugLine="Wait For (ExecuteQuery(cmd)) complete (res As DBR";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", ba, this, _executequery(_cmd));
this.state = 9;
return;
case 9:
//C
this.state = 1;
_res = (b4j.example.main._dbresult) result[0];
;
 //BA.debugLineNum = 114;BA.debugLine="If res <> Null And res.IsInitialized Then";
if (true) break;

case 1:
//if
this.state = 8;
if (_res!= null && _res.IsInitialized /*boolean*/ ) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 115;BA.debugLine="For Each row() As Object In res.Rows";
if (true) break;

case 4:
//for
this.state = 7;
group5 = _res.Rows /*anywheresoftware.b4a.objects.collections.List*/ ;
index5 = 0;
groupLen5 = group5.getSize();
this.state = 10;
if (true) break;

case 10:
//C
this.state = 7;
if (index5 < groupLen5) {
this.state = 6;
_row = (Object[])(group5.Get(index5));}
if (true) break;

case 11:
//C
this.state = 10;
index5++;
if (true) break;

case 6:
//C
this.state = 11;
 //BA.debugLineNum = 116;BA.debugLine="List1.Add(row(0))";
_list1.Add(_row[(int) (0)]);
 if (true) break;
if (true) break;

case 7:
//C
this.state = 8;
;
 //BA.debugLineNum = 118;BA.debugLine="Result = List1.Size";
_result = _list1.getSize();
 if (true) break;

case 8:
//C
this.state = -1;
;
 //BA.debugLineNum = 120;BA.debugLine="Return Result";
if (true) {
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,(Object)(_result));return;};
 //BA.debugLineNum = 121;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _executequery(b4j.example.main._dbcommand _cmd) throws Exception{
ResumableSub_ExecuteQuery rsub = new ResumableSub_ExecuteQuery(null,_cmd);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_ExecuteQuery extends BA.ResumableSub {
public ResumableSub_ExecuteQuery(b4j.example.jrdc2utils parent,b4j.example.main._dbcommand _cmd) {
this.parent = parent;
this._cmd = _cmd;
}
b4j.example.jrdc2utils parent;
b4j.example.main._dbcommand _cmd;
b4j.example.dbrequestmanager _req = null;
b4j.example.httpjob _j = null;
b4j.example.main._dbresult _res = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 57;BA.debugLine="Dim req As DBRequestManager = CreateRequest";
_req = _createrequest();
 //BA.debugLineNum = 59;BA.debugLine="Wait For (req.ExecuteQuery(cmd, 0, Null)) JobDone";
anywheresoftware.b4a.keywords.Common.WaitFor("jobdone", ba, this, (Object)(_req._executequery /*b4j.example.httpjob*/ (_cmd,(int) (0),anywheresoftware.b4a.keywords.Common.Null)));
this.state = 11;
return;
case 11:
//C
this.state = 1;
_j = (b4j.example.httpjob) result[0];
;
 //BA.debugLineNum = 60;BA.debugLine="If j.Success Then";
if (true) break;

case 1:
//if
this.state = 10;
if (_j._success /*boolean*/ ) { 
this.state = 3;
}else {
this.state = 9;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 61;BA.debugLine="req.HandleJobAsync(j, \"req\")";
_req._handlejobasync /*void*/ (_j,"req");
 //BA.debugLineNum = 62;BA.debugLine="If SubExists(Me, \"req_Result\") Then";
if (true) break;

case 4:
//if
this.state = 7;
if (anywheresoftware.b4a.keywords.Common.SubExists(ba,jrdc2utils.getObject(),"req_Result")) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 63;BA.debugLine="Log($\"Going to call Sub \"req_Result\" ...\"$)";
anywheresoftware.b4a.keywords.Common.LogImpl("61835015",("Going to call Sub \"req_Result\" ..."),0);
 if (true) break;

case 7:
//C
this.state = 10;
;
 //BA.debugLineNum = 65;BA.debugLine="Wait For (req) req_result(res As DBResult)			'##";
anywheresoftware.b4a.keywords.Common.WaitFor("req_result", ba, this, (Object)(_req));
this.state = 12;
return;
case 12:
//C
this.state = 10;
_res = (b4j.example.main._dbresult) result[0];
;
 if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 67;BA.debugLine="Dim res As DBResult = Null											'##:? Or ch";
_res = (b4j.example.main._dbresult)(anywheresoftware.b4a.keywords.Common.Null);
 //BA.debugLineNum = 68;BA.debugLine="Log($\"Error executing query: ${j.ErrorMessage}\"$";
anywheresoftware.b4a.keywords.Common.LogImpl("61835020",("Error executing query: "+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_j._errormessage /*String*/ ))+""),0);
 if (true) break;

case 10:
//C
this.state = -1;
;
 //BA.debugLineNum = 70;BA.debugLine="j.Release";
_j._release /*String*/ ();
 //BA.debugLineNum = 71;BA.debugLine="Return res";
if (true) {
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,(Object)(_res));return;};
 //BA.debugLineNum = 72;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _executequery2(Object _mcaller,String _mmethod,b4j.example.main._dbcommand _cmd) throws Exception{
ResumableSub_ExecuteQuery2 rsub = new ResumableSub_ExecuteQuery2(null,_mcaller,_mmethod,_cmd);
rsub.resume(ba, null);
}
public static class ResumableSub_ExecuteQuery2 extends BA.ResumableSub {
public ResumableSub_ExecuteQuery2(b4j.example.jrdc2utils parent,Object _mcaller,String _mmethod,b4j.example.main._dbcommand _cmd) {
this.parent = parent;
this._mcaller = _mcaller;
this._mmethod = _mmethod;
this._cmd = _cmd;
}
b4j.example.jrdc2utils parent;
Object _mcaller;
String _mmethod;
b4j.example.main._dbcommand _cmd;
b4j.example.main._dbresult _res = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = -1;
 //BA.debugLineNum = 75;BA.debugLine="wait for (ExecuteQuery(cmd)) complete (res As DBR";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", ba, this, _executequery(_cmd));
this.state = 1;
return;
case 1:
//C
this.state = -1;
_res = (b4j.example.main._dbresult) result[0];
;
 //BA.debugLineNum = 76;BA.debugLine="CallSubDelayed2(mCaller, mMethod, res)";
anywheresoftware.b4a.keywords.Common.CallSubDelayed2(ba,_mcaller,_mmethod,(Object)(_res));
 //BA.debugLineNum = 77;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _executetableview(b4j.example.main._dbcommand _cmd,anywheresoftware.b4j.objects.TableViewWrapper _tableview1) throws Exception{
ResumableSub_ExecuteTableView rsub = new ResumableSub_ExecuteTableView(null,_cmd,_tableview1);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_ExecuteTableView extends BA.ResumableSub {
public ResumableSub_ExecuteTableView(b4j.example.jrdc2utils parent,b4j.example.main._dbcommand _cmd,anywheresoftware.b4j.objects.TableViewWrapper _tableview1) {
this.parent = parent;
this._cmd = _cmd;
this._tableview1 = _tableview1;
}
b4j.example.jrdc2utils parent;
b4j.example.main._dbcommand _cmd;
anywheresoftware.b4j.objects.TableViewWrapper _tableview1;
int _result = 0;
b4j.example.main._dbresult _res = null;
anywheresoftware.b4a.objects.collections.List _cols = null;
int _i = 0;
Object[] _row = null;
String[] _values = null;
String _value = "";
int _col = 0;
int step7;
int limit7;
anywheresoftware.b4a.BA.IterableList group11;
int index11;
int groupLen11;
int step14;
int limit14;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 124;BA.debugLine="Dim Result As Int = -1";
_result = (int) (-1);
 //BA.debugLineNum = 125;BA.debugLine="TableView1.Items.Clear";
_tableview1.getItems().Clear();
 //BA.debugLineNum = 126;BA.debugLine="Wait For (ExecuteQuery(cmd)) complete (res As DBR";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", ba, this, _executequery(_cmd));
this.state = 17;
return;
case 17:
//C
this.state = 1;
_res = (b4j.example.main._dbresult) result[0];
;
 //BA.debugLineNum = 127;BA.debugLine="If res <> Null And res.IsInitialized Then";
if (true) break;

case 1:
//if
this.state = 16;
if (_res!= null && _res.IsInitialized /*boolean*/ ) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 128;BA.debugLine="Dim cols As List";
_cols = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 129;BA.debugLine="cols.Initialize";
_cols.Initialize();
 //BA.debugLineNum = 130;BA.debugLine="For i = 0 To res.Columns.Size -1";
if (true) break;

case 4:
//for
this.state = 7;
step7 = 1;
limit7 = (int) (_res.Columns /*anywheresoftware.b4a.objects.collections.Map*/ .getSize()-1);
_i = (int) (0) ;
this.state = 18;
if (true) break;

case 18:
//C
this.state = 7;
if ((step7 > 0 && _i <= limit7) || (step7 < 0 && _i >= limit7)) this.state = 6;
if (true) break;

case 19:
//C
this.state = 18;
_i = ((int)(0 + _i + step7)) ;
if (true) break;

case 6:
//C
this.state = 19;
 //BA.debugLineNum = 131;BA.debugLine="cols.Add(res.Columns.GetKeyAt(i))";
_cols.Add(_res.Columns /*anywheresoftware.b4a.objects.collections.Map*/ .GetKeyAt(_i));
 if (true) break;
if (true) break;

case 7:
//C
this.state = 8;
;
 //BA.debugLineNum = 133;BA.debugLine="TableView1.SetColumns(cols)";
_tableview1.SetColumns(_cols);
 //BA.debugLineNum = 134;BA.debugLine="For Each row() As Object In res.Rows";
if (true) break;

case 8:
//for
this.state = 15;
group11 = _res.Rows /*anywheresoftware.b4a.objects.collections.List*/ ;
index11 = 0;
groupLen11 = group11.getSize();
this.state = 20;
if (true) break;

case 20:
//C
this.state = 15;
if (index11 < groupLen11) {
this.state = 10;
_row = (Object[])(group11.Get(index11));}
if (true) break;

case 21:
//C
this.state = 20;
index11++;
if (true) break;

case 10:
//C
this.state = 11;
 //BA.debugLineNum = 135;BA.debugLine="Dim values(res.Columns.Size) As String";
_values = new String[_res.Columns /*anywheresoftware.b4a.objects.collections.Map*/ .getSize()];
java.util.Arrays.fill(_values,"");
 //BA.debugLineNum = 136;BA.debugLine="Dim value As String";
_value = "";
 //BA.debugLineNum = 137;BA.debugLine="For col = 0 To res.Columns.Size - 1";
if (true) break;

case 11:
//for
this.state = 14;
step14 = 1;
limit14 = (int) (_res.Columns /*anywheresoftware.b4a.objects.collections.Map*/ .getSize()-1);
_col = (int) (0) ;
this.state = 22;
if (true) break;

case 22:
//C
this.state = 14;
if ((step14 > 0 && _col <= limit14) || (step14 < 0 && _col >= limit14)) this.state = 13;
if (true) break;

case 23:
//C
this.state = 22;
_col = ((int)(0 + _col + step14)) ;
if (true) break;

case 13:
//C
this.state = 23;
 //BA.debugLineNum = 138;BA.debugLine="value = row(col)";
_value = BA.ObjectToString(_row[_col]);
 //BA.debugLineNum = 139;BA.debugLine="values(col) = value";
_values[_col] = _value;
 if (true) break;
if (true) break;

case 14:
//C
this.state = 21;
;
 //BA.debugLineNum = 141;BA.debugLine="TableView1.Items.Add(values)";
_tableview1.getItems().Add((Object)(_values));
 if (true) break;
if (true) break;

case 15:
//C
this.state = 16;
;
 //BA.debugLineNum = 143;BA.debugLine="Result = res.Rows.Size";
_result = _res.Rows /*anywheresoftware.b4a.objects.collections.List*/ .getSize();
 if (true) break;

case 16:
//C
this.state = -1;
;
 //BA.debugLineNum = 145;BA.debugLine="Return Result";
if (true) {
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,(Object)(_result));return;};
 //BA.debugLineNum = 146;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static int  _getcolumnindex(b4j.example.main._dbresult _res,String _colname) throws Exception{
int _colidx = 0;
anywheresoftware.b4a.objects.collections.Map _columns = null;
String _key = "";
 //BA.debugLineNum = 96;BA.debugLine="Public Sub GetColumnIndex(res As DBResult, colName";
 //BA.debugLineNum = 97;BA.debugLine="Dim colIdx As Int = -1";
_colidx = (int) (-1);
 //BA.debugLineNum = 99;BA.debugLine="Dim columns As Map = res.Columns";
_columns = new anywheresoftware.b4a.objects.collections.Map();
_columns = _res.Columns /*anywheresoftware.b4a.objects.collections.Map*/ ;
 //BA.debugLineNum = 100;BA.debugLine="For Each key As String In columns.Keys";
{
final anywheresoftware.b4a.BA.IterableList group3 = _columns.Keys();
final int groupLen3 = group3.getSize()
;int index3 = 0;
;
for (; index3 < groupLen3;index3++){
_key = BA.ObjectToString(group3.Get(index3));
 //BA.debugLineNum = 101;BA.debugLine="If key.EqualsIgnoreCase(colName) Then";
if (_key.equalsIgnoreCase(_colname)) { 
 //BA.debugLineNum = 102;BA.debugLine="colIdx = columns.Get(key)";
_colidx = (int)(BA.ObjectToNumber(_columns.Get((Object)(_key))));
 //BA.debugLineNum = 103;BA.debugLine="Exit";
if (true) break;
 };
 }
};
 //BA.debugLineNum = 106;BA.debugLine="Return colIdx";
if (true) return _colidx;
 //BA.debugLineNum = 107;BA.debugLine="End Sub";
return 0;
}
public static Object  _getcolumnobject(b4j.example.main._dbresult _res,int _rowidx,String _colname) throws Exception{
int _colidx = 0;
anywheresoftware.b4a.objects.collections.Map _columns = null;
String _key = "";
Object[] _row = null;
 //BA.debugLineNum = 80;BA.debugLine="Public Sub GetColumnObject(res As DBResult, rowIdx";
 //BA.debugLineNum = 83;BA.debugLine="Dim colIdx As Int = -1";
_colidx = (int) (-1);
 //BA.debugLineNum = 84;BA.debugLine="Dim columns As Map = res.Columns";
_columns = new anywheresoftware.b4a.objects.collections.Map();
_columns = _res.Columns /*anywheresoftware.b4a.objects.collections.Map*/ ;
 //BA.debugLineNum = 85;BA.debugLine="For Each key As String In columns.Keys";
{
final anywheresoftware.b4a.BA.IterableList group3 = _columns.Keys();
final int groupLen3 = group3.getSize()
;int index3 = 0;
;
for (; index3 < groupLen3;index3++){
_key = BA.ObjectToString(group3.Get(index3));
 //BA.debugLineNum = 86;BA.debugLine="If key.EqualsIgnoreCase(colName) Then";
if (_key.equalsIgnoreCase(_colname)) { 
 //BA.debugLineNum = 87;BA.debugLine="colIdx = columns.Get(key)";
_colidx = (int)(BA.ObjectToNumber(_columns.Get((Object)(_key))));
 //BA.debugLineNum = 88;BA.debugLine="Exit";
if (true) break;
 };
 }
};
 //BA.debugLineNum = 91;BA.debugLine="If colIdx = -1 Then Return Null";
if (_colidx==-1) { 
if (true) return anywheresoftware.b4a.keywords.Common.Null;};
 //BA.debugLineNum = 92;BA.debugLine="Dim row() As Object = res.Rows.Get(rowIdx)";
_row = (Object[])(_res.Rows /*anywheresoftware.b4a.objects.collections.List*/ .Get(_rowidx));
 //BA.debugLineNum = 93;BA.debugLine="Return row(colIdx)";
if (true) return _row[_colidx];
 //BA.debugLineNum = 94;BA.debugLine="End Sub";
return null;
}
public static String  _intitialize(String _rdcuri) throws Exception{
 //BA.debugLineNum = 9;BA.debugLine="Public Sub Intitialize(rdcUri As String)";
 //BA.debugLineNum = 10;BA.debugLine="rdcLink = rdcUri";
_rdclink = _rdcuri;
 //BA.debugLineNum = 11;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 4;BA.debugLine="Sub Process_Globals														'##:? You're goin";
 //BA.debugLineNum = 5;BA.debugLine="Private rdcLink As String										'##:? How is t";
_rdclink = "";
 //BA.debugLineNum = 6;BA.debugLine="End Sub																				'It is common to use mo";
return "";
}
public static String  _req_result(b4j.example.main._dbresult _adbresult) throws Exception{
 //BA.debugLineNum = 52;BA.debugLine="public Sub req_result(aDBResult As DBResult)					'";
 //BA.debugLineNum = 53;BA.debugLine="Log(\"... [jRDC2Utils.req_Result] Executed\")					'";
anywheresoftware.b4a.keywords.Common.LogImpl("61769473","... [jRDC2Utils.req_Result] Executed",0);
 //BA.debugLineNum = 54;BA.debugLine="End Sub";
return "";
}
}
